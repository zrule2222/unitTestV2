import { mount,RouterLinkStub } from "@vue/test-utils";
import ArticleComponent from "../Componnents/Article.vue"
import { describe, it, expect, vi } from "vitest";
import { getAuthor } from "../Componnents/Article.vue"
import axios from 'axios'
import {articles} from "../Services/articleService.js"
import {shallowMount } from '@vue/test-utils';
import flushPromises from 'flush-promises'
import { nextTick } from 'vue'
import localVue from "./mocks/localVue";
import VueRouter from 'vue-router'


describe("Article.vue", async () => {


    it("should set authorName", async () => {
       
        const Article =    {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }

          const authorName = "Autorius1"


        const wrapper = shallowMount(ArticleComponent, {
           propsData: { Article },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve({name: authorName}))
              }
            }
          }})
 
       await flushPromises()

        expect(wrapper.vm.$data.AuthorName).toBe(authorName);
    });

    it("should get the Article title", async () => {
        const Article =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }

          const authorName = "Autorius1"


          

          const wrapper = shallowMount(ArticleComponent, {
            propsData: { Article },
           mocks:{
             $articles:{
               getAuthors: () => {
                 return new Promise(resolve => resolve({name: authorName}))
               }
             }
           }})
  
        await flushPromises()


        expect(wrapper.find("#title").text()).toBe(Article.title)
    });

    it("should get the Article author", async () => {
        const Article =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }

          const authorName = "Autorius1"


          

          const wrapper = shallowMount(ArticleComponent, {
            propsData: { Article },
           mocks:{
             $articles:{
               getAuthors: () => {
                 return new Promise(resolve => resolve({name: authorName}))
               }
             }
           }})
  
        await flushPromises()


        expect(wrapper.find("#authorName").text()).toBe(authorName)
    });

        it("should get the Article date", async () => {
        const Article =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }

          const authorName = "Autorius1"

          const wrapper = shallowMount(ArticleComponent, {
            propsData: { Article },
           mocks:{
             $articles:{
               getAuthors: () => {
                 return new Promise(resolve => resolve({name: authorName}))
               }
             }
           }})
  
        await flushPromises()


        expect(wrapper.find("#date").text()).toBe(Article.updated_at)
    });

    it("should get the edit button emit", async () => {
        const Article =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }

          const authorName = "Autorius1"
          const showEditValue = 1

          const wrapper = shallowMount(ArticleComponent, {
            propsData: { Article },
           mocks:{
             $articles:{
               getAuthors: () => {
                 return new Promise(resolve => resolve({name: authorName}))
               }
             }
           }})

  
        await flushPromises()
       let button = await wrapper.find('#edit').trigger('click')
       await wrapper.vm.$nextTick() // Wait until $emits have been handled

       expect(wrapper.emitted('show-edit')).toStrictEqual([[showEditValue]])

    });

    it("should delete article and emit delete sucess", async () => {
      const Article =    {
          "id": 1,
          "title": "pirmas",
          "body": "some comment9",
          "author": 1,
          "created_at": "2020-01-01 10:12:31",
          "updated_at": "2023-02-08 09:36:35"
        }
        const authorName = "Autorius1"
        const actionType = 'delete'
        const sucess = 'sucess'

        const wrapper = shallowMount(ArticleComponent, {
          propsData: { Article },
         mocks:{
           $articles:{
             getAuthors: () => {
               return new Promise(resolve => resolve({name: authorName}))
             },
             deleteArticle: () => {
              return new Promise(resolve => resolve())
            }
           }
         }})

      await flushPromises()
     let button = await wrapper.find('#delete').trigger('click')
     await wrapper.vm.$nextTick() // Wait until $emits have been handled
     window.confirm = vi.fn().mockImplementation(() => true)
     await wrapper.findAll('button').at(2).trigger('click')
     expect(window.confirm).toHaveBeenCalled()
     expect(wrapper.emitted('delete-action')).toStrictEqual([[{ actionType: actionType, sucess: sucess}]])

  });

  it("should fail to delete article and emit delete fail", async () => {
    const Article =    {
        "id": 1,
        "title": "pirmas",
        "body": "some comment9",
        "author": 1,
        "created_at": "2020-01-01 10:12:31",
        "updated_at": "2023-02-08 09:36:35"
      }
      const authorName = "Autorius1"
      const actionType = 'delete'
      const sucess = 'failure'

      const wrapper = shallowMount(ArticleComponent, {
        propsData: { Article },
       mocks:{
         $articles:{
           getAuthors: () => {
             return new Promise(resolve => resolve({name: authorName}))
           },
           deleteArticle: () => {
            return new Promise(() => reject())
          }
           
         }
       }})

    await flushPromises()
   let button = await wrapper.find('#delete').trigger('click')
   await wrapper.vm.$nextTick() // Wait until $emits have been handled
   window.confirm = vi.fn().mockImplementation(() => true)
   expect(wrapper.emitted('delete-action')).toStrictEqual([[{ actionType: actionType, sucess: sucess }]])

});

it("should set the correcter router link to prop", async () => {
  vi.mock('vue-router')
  const Article =    {
      "id": 1,
      "title": "pirmas",
      "body": "some comment9",
      "author": 1,
      "created_at": "2020-01-01 10:12:31",
      "updated_at": "2023-02-08 09:36:35"
    }
    const authorName = "Autorius1"
    const name = 'SpesificArticle'
    const params = {id: 1 }

    const wrapper = shallowMount(ArticleComponent, {
      propsData: { Article },
     mocks:{
       $articles:{
         getAuthors: () => {
           return new Promise(resolve => resolve({name: authorName}))
         }
       }
     },
     stubs: {
      RouterLink: RouterLinkStub
    }})
     let button = await wrapper.findAll('button').at(1).trigger('click')
     await wrapper.vm.$nextTick() // Wait until $emits have been handled
     window.location = vi.fn()



     expect(wrapper.find('#redirectToArticle').props().to).toStrictEqual({ name: name, params: params })
});

});