import { mount } from "@vue/test-utils";
import modal from "../Componnents/modal.vue"
import { describe, it, expect } from "vitest";
import {shallowMount } from '@vue/test-utils';
import flushPromises from 'flush-promises'

describe("modal.vue", () => {

    it("should set component data", async () => {
       
        const actionType = 'edit'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})
 
       await flushPromises()

        expect(wrapper.vm.$data.title).toBe(article.title);
        expect(wrapper.vm.$data.content).toBe(article.body);
        expect(wrapper.vm.$data.author).toBe(article.author);
    });

    it("check props", async () => {
       
        const actionType = 'edit'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})
 
       await flushPromises()

        expect(wrapper.vm.actionType).toBe(actionType);
        expect(wrapper.vm.editIndex).toBe(editIndex);
        expect(wrapper.vm.isActive).toBe(isActive);
    });

    it("should get the paragraph with text Edit Article", async () => {
       
        const actionType = 'edit'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }
          const headerText = "Edit Article"


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})
 
       await flushPromises()

       expect(wrapper.find('#editArticle').text()).toBe(headerText)
    });

    it("should get the paragraph with text Add Article", async () => {
       
        const actionType = 'create'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }

          const headerText = "Add Article"

        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})
 
       await flushPromises()

       expect(wrapper.find('#addArticle').text()).toBe(headerText)
    });

    it("check that imput is empty", async () => {
       
        const actionType = 'create'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }
          const titleText = "Tittle is empty"
          const titleClass = "is-danger"


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})
          let button = await wrapper.find('#doAction').trigger('click')
          await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       await flushPromises()

       expect(wrapper.find('#titleEmpty').text()).toBe(titleText)
       expect(wrapper.find('#titleImput').classes(titleClass)).toBe(true)
    });

    it("check that author is empty", async () => {
       
        const actionType = 'create'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }
          const authorText = "Author not selected"
          const authorClass = "is-danger"

        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})
          await wrapper.setData({ title: 'title' })
          let button = await wrapper.find('#doAction').trigger('click')
          await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       await flushPromises()

       expect(wrapper.find('#AuthorSelect').classes(authorClass)).toBe(true)
       expect(wrapper.find('#noAuthor').text()).toBe(authorText)
       
    });

    it("check that content is empty", async () => {
       
        const actionType = 'create'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }

          const contentText = "Content is empty"
          const contentClass = "is-danger"

        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})
          await wrapper.setData({ title: 'title' })
          await wrapper.setData({ author: 2 })
          let button = await wrapper.find('#doAction').trigger('click')
          await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       await flushPromises()

       expect(wrapper.find('#textArea').classes(contentClass)).toBe(true)
       expect(wrapper.find('#noContent').text()).toBe(contentText)
       
    });

    it("should emit close after clicking close button", async () => {
       
        const actionType = 'create'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})

          let button = await wrapper.find('#closeButton').trigger('click')
          await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       await flushPromises()

       expect(wrapper.emitted().close).toStrictEqual([[]])
       
    });

    it("should post article", async () => {
       
        const actionType = 'create'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }

          const type = 'create'
          const sucess = 'sucess'


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              },
              postArticle: () =>{
                return new Promise( resolve => resolve({
                    title: "test",
                    body: "test",
                    author: 1,
                    //created_at: new Date().toLocaleString()
                }))
              }
            }
          }})
          await wrapper.setData({ title: 'test' })
          await wrapper.setData({ author: 1 })
          await wrapper.setData({ content: 'test' })
          let button = await wrapper.find('#doAction').trigger('click')
          await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       await flushPromises()

       expect(wrapper.emitted('close-after-action')).toStrictEqual([[{type: type,sucess: sucess}]])
       
    });

    it("should fail to post article", async () => {
       
        const actionType = 'create'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }
          const type = 'create'
          const sucess = 'failure'


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              },
              postArticle: () =>{
                return new Promise( () => reject())
              }
            }
          }})
          await wrapper.setData({ title: 'test' })
          await wrapper.setData({ author: 1 })
          await wrapper.setData({ content: 'test' })
          let button = await wrapper.find('#doAction').trigger('click')
          await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       await flushPromises()

       expect(wrapper.emitted('close-after-action')).toStrictEqual([[{type: type,sucess: sucess}]])
       
    });

    it("should update article", async () => {
       
        const actionType = 'edit'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }

          const type = 'update'
          const sucess = 'sucess'


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              },
              updateArticle: () =>{
                return new Promise( resolve => resolve())
              }
            }
          }})
          await wrapper.setData({ title: article.title })
          await wrapper.setData({ author: article.author })
          await wrapper.setData({ content: article.body})
          let button = await wrapper.find('#doAction').trigger('click')
          await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       await flushPromises()

       expect(wrapper.emitted('close-after-action')).toStrictEqual([[{type: type,sucess: sucess}]])
       
    });

    it("should fail to update article", async () => {
       
        const actionType = 'edit'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }

          const type = 'update'
          const sucess = 'failure'


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              },
              updateArticle: () =>{
                return new Promise( () => reject())
              }
            }
          }})
          await wrapper.setData({ title: article.title })
          await wrapper.setData({ author: article.author })
          await wrapper.setData({ content: article.body})
          let button = await wrapper.find('#doAction').trigger('click')
          await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       await flushPromises()

       expect(wrapper.emitted('close-after-action')).toStrictEqual([[{type: type,sucess: sucess}]])
       
    });

    it("should isActive class should be set on a div", async () => {
       
        const actionType = 'edit'
        const editIndex = 1
        const isActive = true
        const Authors = [
            {
              "id": 1,
              "name": "Autorius1",
              "created_at": "",
              "updated_at": ""
            },
            {
              "id": 2,
              "name": "Autorius2",
              "created_at": "a",
              "updated_at": "b"
            }
          ]
          const article = {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }

          const className = "is-active"


        const wrapper = shallowMount(modal, {
           propsData: { actionType,editIndex,isActive },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve(Authors))
              },
              getArticles: () => {
                return new Promise(resolve => resolve(article))
              }
            }
          }})

 
       await flushPromises()

       expect(wrapper.find("#isActiveDiv").classes(className)).toBe(true)
       
    });

    
});