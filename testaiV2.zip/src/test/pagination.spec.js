import { mount } from "@vue/test-utils";
import pagination from "../Componnents/pagination.vue"
import { describe, it, expect } from "vitest";
import {shallowMount } from '@vue/test-utils';
import flushPromises from 'flush-promises'

describe("modal.vue", () => {

    it("check props", async () => {
       
        const pages = 5
        const currentPage = 1

        const wrapper = shallowMount(pagination, {
           propsData: { pages,currentPage }
        })
 

        expect(wrapper.vm.pages).toBe(pages);
        expect(wrapper.vm.currentPage).toBe(currentPage);
    });

    it("check if is-current class is added when pages and current page are equal", async () => {
       
        const pages = 5
        const currentPage = 5
        const className = "is-current"

        const wrapper = shallowMount(pagination, {
           propsData: { pages,currentPage }
        })
 
       //console.log( wrapper.findAll('li').at(4).key)
        expect(wrapper.find('#page5').classes(className)).toBe(true)
    });

    it("should emmit after clicking li", async () => {
       
        const pages = 5
        const currentPage = 1
        const clickedPage = 4

        const wrapper = shallowMount(pagination, {
           propsData: { pages,currentPage }
        })

        let button = await wrapper.find(`#page${clickedPage}`).trigger('click')
        await wrapper.vm.$nextTick() // Wait until $emits have been handled
 
       //console.log( wrapper.findAll('li').at(4).key)
       expect(wrapper.emitted('onPageChange')).toStrictEqual([[{page: clickedPage}]])
    });


    it("check if correct number of li is created", async () => {
       
        const pages = 5
        const currentPage = 1

        const wrapper = shallowMount(pagination, {
           propsData: { pages,currentPage }
        })

       
       expect(wrapper.findAll('li').length).toBe(pages)
    });
});