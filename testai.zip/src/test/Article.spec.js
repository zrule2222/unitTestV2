import { mount } from "@vue/test-utils";
import ArticleComponent from "../Componnents/Article.vue"
import { describe, it, expect, vi } from "vitest";
import { getAuthor } from "../Componnents/Article.vue"
import axios from 'axios'
import {articles} from "../Services/articleService.js"
import {shallowMount } from '@vue/test-utils';
import flushPromises from 'flush-promises'
import { nextTick } from 'vue'
import localVue from "../mocks/localVue";
import VueRouter from 'vue-router'


describe("Article.vue", async () => {


    it("should set authorName", async () => {
       
        const Article =    {
            id: 1,
            title: "pirmas",
            body: "some comment9",
            author: 1,
            created_at: "2020-01-01 10:12:31",
            updated_at: "2023-02-08 09:36:35"
          }
       
        const Propvalue =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }

        let aa = Article.author

        const wrapper = shallowMount(ArticleComponent, {
           propsData: { Article },
          mocks:{
            $articles:{
              getAuthors: () => {
                return new Promise(resolve => resolve({name: "Autorius1"}))
              }
            }
          }})
 
       await flushPromises()

        expect(wrapper.vm.$data.AuthorName).toBe("Autorius1");
    });

    it("should get the Article title", async () => {
        const Article =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }


          

          const wrapper = shallowMount(ArticleComponent, {
            propsData: { Article },
           mocks:{
             $articles:{
               getAuthors: () => {
                 return new Promise(resolve => resolve({name: "Autorius1"}))
               }
             }
           }})
  
        await flushPromises()


        expect(wrapper.find("p").text()).toBe("pirmas")
    });

    it("should get the Article author", async () => {
        const Article =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }


          

          const wrapper = shallowMount(ArticleComponent, {
            propsData: { Article },
           mocks:{
             $articles:{
               getAuthors: () => {
                 return new Promise(resolve => resolve({name: "Autorius1"}))
               }
             }
           }})
  
        await flushPromises()


        expect(wrapper.findAll("p").at(1).text()).toBe("Autorius1")
    });

        it("should get the Article date", async () => {
        const Article =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }


          

          const wrapper = shallowMount(ArticleComponent, {
            propsData: { Article },
           mocks:{
             $articles:{
               getAuthors: () => {
                 return new Promise(resolve => resolve({name: "Autorius1"}))
               }
             }
           }})
  
        await flushPromises()


        expect(wrapper.findAll("p").at(2).text()).toBe("2023-02-08 09:36:35")
    });

    it("should get the edit button emit", async () => {
        const Article =    {
            "id": 1,
            "title": "pirmas",
            "body": "some comment9",
            "author": 1,
            "created_at": "2020-01-01 10:12:31",
            "updated_at": "2023-02-08 09:36:35"
          }


          

          const wrapper = shallowMount(ArticleComponent, {
            propsData: { Article },
           mocks:{
             $articles:{
               getAuthors: () => {
                 return new Promise(resolve => resolve({name: "Autorius1"}))
               }
             }
           }})
  
        await flushPromises()
       let button = await wrapper.findAll('button').at(1).trigger('click')
       await wrapper.vm.$nextTick() // Wait until $emits have been handled

       expect(wrapper.emitted('show-edit')).toStrictEqual([[1]])

        //expect( wrapper.emitted().toEqual(['show-edit']))
       // expect(wrapper.emitted().toEqual(['show-edit']))
    });

    it("should delete article and emit delete sucess", async () => {
      const Article =    {
          "id": 1,
          "title": "pirmas",
          "body": "some comment9",
          "author": 1,
          "created_at": "2020-01-01 10:12:31",
          "updated_at": "2023-02-08 09:36:35"
        }


        

        const wrapper = shallowMount(ArticleComponent, {
          propsData: { Article },
         mocks:{
           $articles:{
             getAuthors: () => {
               return new Promise(resolve => resolve({name: "Autorius1"}))
             },
             deleteArticle: () => {
              return new Promise(resolve => resolve())
            }
           }
         }})

      await flushPromises()
     let button = await wrapper.findAll('button').at(2).trigger('click')
     await wrapper.vm.$nextTick() // Wait until $emits have been handled
     window.confirm = vi.fn().mockImplementation(() => true)
     await wrapper.findAll('button').at(2).trigger('click')
     expect(window.confirm).toHaveBeenCalled()
     expect(wrapper.emitted('delete-action')).toStrictEqual([[{ actionType: 'delete', sucess: 'sucess' }]])

  });

  it("should fail to delete article and emit delete fail", async () => {
    const Article =    {
        "id": 1,
        "title": "pirmas",
        "body": "some comment9",
        "author": 1,
        "created_at": "2020-01-01 10:12:31",
        "updated_at": "2023-02-08 09:36:35"
      }


      

      const wrapper = shallowMount(ArticleComponent, {
        propsData: { Article },
       mocks:{
         $articles:{
           getAuthors: () => {
             return new Promise(resolve => resolve({name: "Autorius1"}))
           },
           deleteArticle: () => {
            return new Promise(resolve => reject())
          }
           
         }
       }})

    await flushPromises()
   let button = await wrapper.findAll('button').at(2).trigger('click')
   await wrapper.vm.$nextTick() // Wait until $emits have been handled
   window.confirm = vi.fn().mockImplementation(() => true)
   await wrapper.findAll('button').at(2).trigger('click')
   //expect(window.confirm).toHaveBeenCalled()
   expect(wrapper.emitted('delete-action')).toStrictEqual([[{ actionType: 'delete', sucess: 'failure' }]])

});

});