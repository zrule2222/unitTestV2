# Vue 2 + Vite

This skeleton project should help get you started developing with Vue 2 in Vite.
This project has all the necessary dependencies to start doing unit testint for Vue 2.

## Getting started
To install necessary packages, run this command:
```npm install ```

To start your project:
``` npm run dev```

To run tests:
``` npm run test```
